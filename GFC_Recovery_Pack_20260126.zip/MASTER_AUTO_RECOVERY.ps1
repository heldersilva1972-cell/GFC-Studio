# MASTER AUTO-RECOVERY ENGINE
# Run this as Administrator to recover the entire stack

Write-Host "=======================================" -ForegroundColor Magenta
Write-Host "   GFC STUDIO MASTER RECOVERY ENGINE   " -ForegroundColor Magenta
Write-Host "=======================================" -ForegroundColor Magenta

$step = Read-Host "Start Full Recovery? (Y/N)"
if ($step -ne 'Y') { exit }

Write-Host "[STEP 1] Installing Prerequisites..."
.\STEP_1_INSTALL_PREREQS.ps1

Write-Host "[STEP 2] Restoring Database..."
.\STEP_2_SQL_AUTO_RESTORE.ps1

Write-Host "[STEP 3] Configuring IIS Web Server..."
.\STEP_3_IIS_RESTORE.ps1

Write-Host "[STEP 4] Setting Folder Permissions..."
.\STEP_4_FIX_PERMISSIONS.ps1

Write-Host "[STEP 5] Setting up Remote Access Service..."
.\STEP_5_CLOUDFLARED_SERVICE.ps1

Write-Host "[FINAL] Verifying Health..."
.\VERIFY_HEALTH.ps1

Write-Host "SYSTEM RECOVEY COMPLETE." -ForegroundColor Green
