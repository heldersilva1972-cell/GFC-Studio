# Automatic Prerequisite Provisioner
# Uses Windows Package Manager (winget)

Write-Host "GFC System: Provisioning Infrastructure..." -ForegroundColor Cyan

# 1. Install SQL Express
Write-Host "Installing SQL Server 2022 Express..."
winget install Microsoft.SQLServer.2022.Express --silent --accept-package-agreements --accept-source-agreements

# 2. Install .NET Hosting Bundle
Write-Host "Installing .NET 8 Hosting Bundle..."
winget install Microsoft.DotNet.AspNetCore.8 --silent

# 3. Install Cloudflared
Write-Host "Installing Cloudflared (Tunnel Engine)..."
winget install Cloudflare.cloudflared --silent

# 4. Install Management Tools
Write-Host "Installing SQL Management Studio..."
winget install Microsoft.SQLServerManagementStudio --silent

Write-Host "Provisioning Complete. Please REBOOT before proceeding to Step 2." -ForegroundColor Green
