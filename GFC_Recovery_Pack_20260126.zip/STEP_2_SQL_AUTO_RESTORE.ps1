# SQL Smart Restore Engine
# Database: ClubMembership

$dbName = "ClubMembership"
$instance = ".\SQLEXPRESS"

Write-Host "Searching for latest backup in current directory..." -ForegroundColor Cyan
$latestBak = Get-ChildItem -Filter "*.bak" | Sort-Object LastWriteTime -Descending | Select-Object -First 1

if ($latestBak) {
    Write-Host "Found Backup: $($latestBak.Name)" -ForegroundColor Green
    $bakPath = $latestBak.FullName
    
    $sql = "RESTORE DATABASE [$dbName] FROM DISK = '$bakPath' WITH REPLACE, RECOVERY"
    Write-Host "Executing SQL Restore on $instance..." -ForegroundColor Yellow
    
    sqlcmd -S $instance -E -Q $sql
    Write-Host "Restore attempt complete." -ForegroundColor Green
} else {
    Write-Host "No .bak files found in this folder. Please copy a backup here and re-run." -ForegroundColor Red
    Write-Host "Manual Command: RESTORE DATABASE [$dbName] FROM DISK = 'PATH_TO_BACKUP.bak' WITH REPLACE, RECOVERY"
}
