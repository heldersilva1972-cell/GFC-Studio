# NTFS Permission Guard
# Sets up folder security for the IIS User

$path = "C:\Users\hnsil\Documents\GFC\cursor files\GFC-System\GFC-Studio V2\apps\webapp\GFC.BlazorServer"
$iisUser = "IIS AppPool\Unknown"

Write-Host "Securing Paths at $path..." -ForegroundColor Cyan

$folders = @("uploads", "temp", "logs", "wwwroot/uploads")

foreach($f in $folders) {
    $fullPath = Join-Path $path $f
    if (!(Test-Path $fullPath)) {
        New-Item -ItemType Directory -Force -Path $fullPath | Out-Null
    }
    
    Write-Host "Granting Modify Access to $iisUser on $f"
    icacls $fullPath /grant "${iisUser}:(OI)(CI)(M)" /inheritance:e | Out-Null
}

Write-Host "Permissions Hardened." -ForegroundColor Green
