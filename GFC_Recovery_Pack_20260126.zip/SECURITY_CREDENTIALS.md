# Security Credentials Manifest
⚠️ **RESTRICTED ACCESS - DISASTER RECOVERY ONLY**

## Communications Setup
- **Twilio Account**: 
- **SMTP Host**: Not Configured
- **SMTP Port**: 587
- **From Address**: 

## Web Push (VAPID)
- **Public Key**: BOvA9nhGWQ1Ffk6g25JBzeZZ4EJ1MGIh0oMDM7NNpxbXkK6TF19Yv3a3ZTrjx2m5azc6lCfhXbluxwmazHVa6Fc
- **Subject**: Not Set
