# Verify Online Script

$url = "http://localhost"
try {
    $response = Invoke-WebRequest -Uri $url -Method Head -ErrorAction Stop
    if ($response.StatusCode -eq 200) {
        Write-Host "Local Application is ONLINE" -ForegroundColor Green
    }
} catch {
    Write-Host "Local Application Check FAILED" -ForegroundColor Red
}
