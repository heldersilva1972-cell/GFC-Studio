# Troubleshooting

## Mixed Content / SSL Issues
- Ensure `X-Forwarded-Proto` header is being passed by Cloudflared.
- Ensure app `appsettings.json` has `ForwardedHeaders` config enabled.

## 502 Bad Gateway
- Check if the Web App is running in IIS.
- Check if the App Pool is started.
- Check `cloudflared` logs (`C:\ProgramData\cloudflared`).

## SQL Connection Errors
- Verify SQL Server Browser service is running if using Named Instance.
- Verify TCP/IP is enabled in SQL Server Configuration Manager.
