# Disaster Recovery Pack

This pack contains the necessary scripts and documentation to restore the GFC Studio application stack from scratch.

## Contents
- **CHECKLIST.md**: Step-by-step restoration guide.
- **SYSTEM_SNAPSHOT.json**: The state of the system when this pack was generated.
- **Scripts**: PowerShell scripts to automate parts of the recovery.

## Usage
1. Unzip this pack to a secure location.
2. Open `CHECKLIST.md` and follow the instructions.
