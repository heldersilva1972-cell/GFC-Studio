# Network Infrastructure Map
Generated on: 1/26/2026 7:14:25 AM

## Access Controllers
- **Card Access Controller**: 192.168.0.196 (Type: )

## Camera Nodes (Auto-Discovered)
- **01 rear lot/dumpster**: 
- **01 rear lot/dumpster**: 
- **01 rear lot/dumpster**: 
- **01 rear lot/dumpster**: 
- **02 function hall1**: 
- **03 lot/ dumpster**: 
- **06 kitchen**: 
- **05 front/ main entry2**: 
- **07 rear/delivery drive**: 
- **05 front/ main entry2**: 
