# Restoration Checklist

- [ ] **1. Infrastructure Prep**
  - [ ] Install Windows Server / Windows 10/11
  - [ ] Set Time Zone & Sync Clock
  - [ ] Disable Sleep/Hibernate (Power Settings)
  - [ ] Install prerequisites (See KNOWN_DEPENDENCIES.md)

- [ ] **2. Database Restore**
  - [ ] Install SQL Server Express
  - [ ] Run `SQL_BACKUP_RESTORE.ps1`
  - [ ] Verify connectivity

- [ ] **3. Web App Hosting**
  - [ ] Install IIS & Hosting Bundle
  - [ ] Run `IIS_RESTORE.ps1`
  - [ ] Copy application files to physical path

- [ ] **4. Public Access**
  - [ ] Run `CLOUDFLARED_RESTORE.ps1`
  - [ ] Verify tunnel status

- [ ] **5. Final Verification**
  - [ ] Run `VERIFY_ONLINE.ps1`
