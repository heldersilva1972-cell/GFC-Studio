# Known Dependencies

1. **.NET Hosting Bundle**
   - Version: 8.0 (or matching app version)
   - Required for IIS hosting.

2. **Microsoft SQL Server Express**
   - Version: 2019 or later.
   - Authentication: Mixed Mode (SQL Auth + Windows Auth).

3. **Cloudflared (Cloudflare Tunnel)**
   - Required for public access without opening firewall ports.

4. **IIS (Internet Information Services)**
   - Enabled features: Web Server, WebSocket Protocol, ASP.NET 4.8 (if needed), Application Initialization.
