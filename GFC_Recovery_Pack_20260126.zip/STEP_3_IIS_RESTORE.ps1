# IIS Restore Script
# Generated for: Unknown (Not in IIS?)
# Path: C:\Users\hnsil\Documents\GFC\cursor files\GFC-System\GFC-Studio V2\apps\webapp\GFC.BlazorServer

Write-Host "Restoring IIS Configuration..." -ForegroundColor Cyan

# Ensure IIS is installed
# Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole -All

# Create App Pool
$poolName = "Unknown"
if (!(Get-WebAppPoolState -Name $poolName -ErrorAction SilentlyContinue)) {
    Write-Host "Creating App Pool: $poolName"
    New-WebAppPool -Name $poolName
    Set-ItemProperty "IIS:\AppPools\$poolName" -Name "managedRuntimeVersion" -Value ""
    Set-ItemProperty "IIS:\AppPools\$poolName" -Name "startMode" -Value "AlwaysRunning"
}

# Create Site
$siteName = "Unknown (Not in IIS?)"
$path = "C:\Users\hnsil\Documents\GFC\cursor files\GFC-System\GFC-Studio V2\apps\webapp\GFC.BlazorServer"
if (!(Get-Website -Name $siteName -ErrorAction SilentlyContinue)) {
    Write-Host "Creating Site: $siteName"
    New-Website -Name $siteName -PhysicalPath $path -Port 80 -ApplicationPool $poolName
}

Write-Host "IIS Restore Complete." -ForegroundColor Green
