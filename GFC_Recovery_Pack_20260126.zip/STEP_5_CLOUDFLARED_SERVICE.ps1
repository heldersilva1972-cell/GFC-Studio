# Cloudflared Restore Script

Write-Host "Restoring Cloudflare Tunnel..." -ForegroundColor Cyan

# 1. Check for Config
if (!(Test-Path "C:\ProgramData\cloudflared\config.yml")) {
    Write-Warning "Config file missing at C:\ProgramData\cloudflared\config.yml"
    Write-Host "Please place your 'config.yml' and certificate file in the directory."
}

# 2. Install Service
# cloudflared.exe service install

# 3. Start Service
# Start-Service cloudflared

Write-Host "Check status with: Get-Service cloudflared"
