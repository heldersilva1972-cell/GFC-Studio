GFC Ecosystem Docs v1.0.0 R3 — SHORTPATH_FULL
This is the COMPLETE R3 documentation pack repackaged to avoid Windows path-too-long extraction failures.
Folders:
  FINAL/   authoritative specs (build from these)
  WEBSITE/ baseline website mapping/template docs
  SOURCE/  reference + audits + scans (flattened)
