GFC Ecosystem Documentation Pack (Short Path)
Version: v1.0.0  Revision: R3 (ShortPath)

This ZIP is identical in content intent to the R3 pack but packaged with short folder paths
to avoid Windows 'path too long' extraction errors.

Top-level folders:
  FINAL/  - authoritative specs
  WEBSITE/ - website baseline/mapping (if present)
  SOURCE/ - original reference docs
